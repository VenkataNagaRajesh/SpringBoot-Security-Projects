package com.example.kafkaspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
